# ✦ Forge Browser Extension

Refines your prompts and recommends follow-ups inside **any** AI chat — ChatGPT, Claude, Gemini, Perplexity, Copilot, DeepSeek, Mistral, Grok, Poe, character.ai, your own apps, anywhere a textarea or rich editor exists.

## Install (unpacked)

1. Run the Forge backend locally (default `http://localhost:8000`) — see the parent `forge_backend/README.md`.
2. Open `chrome://extensions` (works in Chrome, Edge, Brave, Arc, Opera).
3. Toggle **Developer mode** (top right).
4. Click **Load unpacked** and select this `forge_extension/` folder.
5. Pin the **✦ Forge** icon and open the popup to set your backend URL.

## Use

- Focus any text input on any site.
- A floating **✦ Forge** pill appears above the input.
- Click **Forge** (or press `Ctrl/⌘ + Shift + F`) to rewrite your prompt.
- Click **↺** to undo, **↪** to get follow-up prompt suggestions based on the visible conversation.
- Click **⚙** or the toolbar icon to toggle memory and change the backend URL.

## Memory & privacy

Conversation memory lives **only in the current tab** while you're chatting. Toggling it off — or closing the tab — wipes it immediately. Nothing about the conversation is persisted on the backend; transcripts are only sent when you press **↪** to ask for follow-ups.
