/* Forge content script — universal prompt refiner overlay */
(() => {
  if (window.__forgeInjected) return;
  window.__forgeInjected = true;

  const DEFAULT_API = "http://localhost:8000";
  let SETTINGS = { apiUrl: DEFAULT_API, memory: true, enabled: true };
  let currentInput = null;
  let lastRefineOriginal = null;
  let convoCache = []; // [{role, content}]

  // ---------- settings ----------
  chrome.storage.sync.get(["apiUrl", "memory", "enabled"], (s) => {
    if (s.apiUrl) SETTINGS.apiUrl = s.apiUrl;
    if (typeof s.memory === "boolean") SETTINGS.memory = s.memory;
    if (typeof s.enabled === "boolean") SETTINGS.enabled = s.enabled;
  });
  chrome.storage.onChanged.addListener((c) => {
    if (c.apiUrl) SETTINGS.apiUrl = c.apiUrl.newValue;
    if (c.memory) SETTINGS.memory = c.memory.newValue;
    if (c.enabled) {
      SETTINGS.enabled = c.enabled.newValue;
      if (!SETTINGS.enabled) hidePill();
    }
  });

  // ---------- input detection ----------
  const isEditable = (el) => {
    if (!el || el.disabled || el.readOnly) return false;
    const tag = el.tagName;
    if (tag === "TEXTAREA") return true;
    if (tag === "INPUT" && /^(text|search|url|email)$/i.test(el.type || "text")) return true;
    if (el.isContentEditable) return true;
    return false;
  };

  const getValue = (el) =>
    el.isContentEditable ? (el.innerText || "").trim() : (el.value || "").trim();

  const setValue = (el, text) => {
    if (el.isContentEditable) {
      el.focus();
      // Try execCommand for compatibility with rich editors (ProseMirror/Lexical/etc.)
      try {
        document.execCommand("selectAll", false, null);
        document.execCommand("insertText", false, text);
      } catch {
        el.innerText = text;
      }
      el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    } else {
      const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
      setter.call(el, text);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
  };

  // ---------- pill UI ----------
  const pill = document.createElement("div");
  pill.className = "forge-pill forge-hidden";
  pill.innerHTML = `
    <button class="forge-btn forge-refine" title="Refine this prompt (Ctrl/⌘+Shift+F)">
      <span class="forge-spark">✦</span><span>Forge</span>
    </button>
    <button class="forge-btn forge-icon forge-followup" title="Suggest follow-up prompts">↪</button>
    <button class="forge-btn forge-icon forge-undo forge-disabled" title="Undo refinement">↺</button>
    <button class="forge-btn forge-icon forge-settings" title="Open settings">⚙</button>
  `;
  document.documentElement.appendChild(pill);

  const panel = document.createElement("div");
  panel.className = "forge-panel forge-hidden";
  document.documentElement.appendChild(panel);

  const showPill = (el) => {
    if (!SETTINGS.enabled) return;
    currentInput = el;
    const r = el.getBoundingClientRect();
    const top = window.scrollY + r.top - 38;
    const left = window.scrollX + Math.max(8, r.right - 260);
    pill.style.top = `${Math.max(8, top)}px`;
    pill.style.left = `${left}px`;
    pill.classList.remove("forge-hidden");
  };
  const hidePill = () => {
    pill.classList.add("forge-hidden");
    panel.classList.add("forge-hidden");
  };

  document.addEventListener("focusin", (e) => {
    if (isEditable(e.target)) showPill(e.target);
  }, true);
  document.addEventListener("focusout", (e) => {
    setTimeout(() => {
      const a = document.activeElement;
      if (!isEditable(a) && !pill.contains(a) && !panel.contains(a)) hidePill();
    }, 150);
  }, true);
  window.addEventListener("scroll", () => { if (currentInput) showPill(currentInput); }, true);
  window.addEventListener("resize", () => { if (currentInput) showPill(currentInput); });

  // ---------- API ----------
  const api = (path, body) =>
    fetch(SETTINGS.apiUrl.replace(/\/$/, "") + path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }).then(async (r) => {
      if (!r.ok) throw new Error(`API ${r.status}`);
      return r.json();
    });

  // ---------- refine ----------
  const refineBtn = pill.querySelector(".forge-refine");
  const undoBtn = pill.querySelector(".forge-undo");
  const followBtn = pill.querySelector(".forge-followup");
  const settingsBtn = pill.querySelector(".forge-settings");

  refineBtn.addEventListener("click", async () => {
    if (!currentInput) return;
    const text = getValue(currentInput);
    if (!text) return toast("Type a prompt first");
    refineBtn.classList.add("forge-loading");
    try {
      const { refined } = await api("/api/refine-quick", {
        prompt: text,
        context: location.hostname,
      });
      lastRefineOriginal = text;
      setValue(currentInput, refined);
      undoBtn.classList.remove("forge-disabled");
      if (SETTINGS.memory) {
        convoCache.push({ role: "user", content: refined });
        if (convoCache.length > 24) convoCache = convoCache.slice(-24);
      }
      toast("Prompt forged ✓");
    } catch (e) {
      toast("Forge failed: " + e.message);
    } finally {
      refineBtn.classList.remove("forge-loading");
    }
  });

  undoBtn.addEventListener("click", () => {
    if (lastRefineOriginal != null && currentInput) {
      setValue(currentInput, lastRefineOriginal);
      lastRefineOriginal = null;
      undoBtn.classList.add("forge-disabled");
    }
  });

  // ---------- follow-ups ----------
  followBtn.addEventListener("click", async () => {
    if (!SETTINGS.memory) return openPanelMessage(
      "Memory is off",
      "Turn memory on in settings so Forge can read the conversation and recommend follow-ups."
    );
    const transcript = collectVisibleTranscript();
    const messages = transcript.length ? transcript : convoCache;
    if (!messages.length) return openPanelMessage(
      "Nothing to coach yet",
      "Send a message first, then click ↪ to get follow-up ideas."
    );
    openPanelMessage("Thinking…", "Analysing your conversation.");
    try {
      const data = await api("/api/follow-ups", { messages });
      renderSuggestions(data.suggestions || []);
    } catch (e) {
      openPanelMessage("Couldn't fetch follow-ups", e.message);
    }
  });

  settingsBtn.addEventListener("click", () => chrome.runtime.sendMessage({ type: "openPopup" }));

  // ---------- shortcut ----------
  document.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === "F" || e.key === "f")) {
      const a = document.activeElement;
      if (isEditable(a)) {
        e.preventDefault();
        currentInput = a;
        refineBtn.click();
      }
    }
  }, true);

  // ---------- transcript scraping (best-effort, generic) ----------
  // Captures visible chat turns from common AI chat layouts. Memory stays in this tab only.
  function collectVisibleTranscript() {
    const selectors = [
      '[data-message-author-role]',          // ChatGPT
      '[data-testid^="conversation-turn"]',  // ChatGPT alt
      '.font-claude-message, .font-user-message', // Claude
      '[data-message-id]',                   // Generic
      '.chat-message, .message',             // Generic
    ];
    const nodes = [];
    for (const sel of selectors) {
      document.querySelectorAll(sel).forEach((n) => nodes.push(n));
      if (nodes.length) break;
    }
    if (!nodes.length) return [];
    const out = [];
    nodes.slice(-12).forEach((n) => {
      const role = (n.getAttribute("data-message-author-role") ||
        (n.className.includes("user") ? "user" :
         n.className.includes("assistant") || n.className.includes("claude") ? "assistant" : "user")
      ).toLowerCase();
      const text = (n.innerText || "").trim().slice(0, 4000);
      if (text) out.push({ role: role === "assistant" ? "assistant" : "user", content: text });
    });
    return out;
  }

  // ---------- panel rendering ----------
  function openPanelMessage(title, body) {
    panel.innerHTML = `
      <div class="forge-panel-head">
        <div class="forge-panel-title">${escapeHtml(title)}</div>
        <button class="forge-x" aria-label="Close">×</button>
      </div>
      <div class="forge-panel-body">${escapeHtml(body)}</div>
    `;
    panel.querySelector(".forge-x").onclick = () => panel.classList.add("forge-hidden");
    positionPanel();
  }

  function renderSuggestions(suggestions) {
    if (!suggestions.length) return openPanelMessage("No suggestions", "Try sending another turn first.");
    panel.innerHTML = `
      <div class="forge-panel-head">
        <div class="forge-panel-title">✦ Follow-up suggestions</div>
        <button class="forge-x" aria-label="Close">×</button>
      </div>
      <div class="forge-panel-body">
        ${suggestions.map((s, i) => `
          <button class="forge-suggestion" data-i="${i}">
            <div class="forge-sug-label">${escapeHtml(s.label || "Suggestion " + (i+1))}</div>
            <div class="forge-sug-prompt">${escapeHtml(s.prompt || "")}</div>
            ${s.why ? `<div class="forge-sug-why">${escapeHtml(s.why)}</div>` : ""}
          </button>
        `).join("")}
        <div class="forge-panel-foot">
          ${SETTINGS.memory
            ? `<span>Memory on · this tab only</span>
               <button class="forge-clear-mem">Forget conversation</button>`
            : `<span>Memory off</span>`}
        </div>
      </div>
    `;
    panel.querySelector(".forge-x").onclick = () => panel.classList.add("forge-hidden");
    panel.querySelectorAll(".forge-suggestion").forEach((b) => {
      b.onclick = () => {
        const s = suggestions[+b.dataset.i];
        if (currentInput) setValue(currentInput, s.prompt);
        panel.classList.add("forge-hidden");
        toast("Inserted ✓");
      };
    });
    const clearBtn = panel.querySelector(".forge-clear-mem");
    if (clearBtn) clearBtn.onclick = () => {
      convoCache = [];
      toast("Conversation forgotten");
      panel.classList.add("forge-hidden");
    };
    positionPanel();
  }

  function positionPanel() {
    const r = pill.getBoundingClientRect();
    panel.style.top = `${window.scrollY + r.bottom + 8}px`;
    panel.style.left = `${window.scrollX + r.left}px`;
    panel.classList.remove("forge-hidden");
  }

  // ---------- toast ----------
  let toastEl;
  function toast(msg) {
    if (!toastEl) {
      toastEl = document.createElement("div");
      toastEl.className = "forge-toast";
      document.documentElement.appendChild(toastEl);
    }
    toastEl.textContent = msg;
    toastEl.classList.add("forge-show");
    clearTimeout(toastEl._t);
    toastEl._t = setTimeout(() => toastEl.classList.remove("forge-show"), 2200);
  }

  // ---------- forget on tab close ----------
  window.addEventListener("beforeunload", () => {
    if (!SETTINGS.memory) convoCache = [];
  });

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;" }[c]));
  }
})();
