// Background service worker — opens popup on demand & ping
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "openPopup") {
    // chrome.action.openPopup() requires user gesture in MV3 — we just no-op here.
    sendResponse({ ok: true });
  }
  return true;
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get(["apiUrl", "memory", "enabled"], (s) => {
    const defaults = {};
    if (!s.apiUrl) defaults.apiUrl = "http://localhost:8000";
    if (typeof s.memory !== "boolean") defaults.memory = true;
    if (typeof s.enabled !== "boolean") defaults.enabled = true;
    if (Object.keys(defaults).length) chrome.storage.sync.set(defaults);
  });
});
