const $ = (id) => document.getElementById(id);

chrome.storage.sync.get(["apiUrl", "memory", "enabled"], (s) => {
  $("apiUrl").value = s.apiUrl || "http://localhost:8000";
  $("memory").checked = s.memory !== false;
  $("enabled").checked = s.enabled !== false;
});

$("save").addEventListener("click", () => {
  chrome.storage.sync.set({
    apiUrl: $("apiUrl").value.trim() || "http://localhost:8000",
    memory: $("memory").checked,
    enabled: $("enabled").checked,
  }, () => {
    const s = $("saved");
    s.classList.add("show");
    setTimeout(() => s.classList.remove("show"), 1500);
  });
});
